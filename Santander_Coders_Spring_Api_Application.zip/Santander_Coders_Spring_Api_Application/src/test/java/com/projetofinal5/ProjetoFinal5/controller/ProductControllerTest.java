package com.projetofinal5.ProjetoFinal5.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.projetofinal5.ProjetoFinal5.dto.ProductListDTO;
import com.projetofinal5.ProjetoFinal5.entity.ProductEntity;
import com.projetofinal5.ProjetoFinal5.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ProductControllerTest {

	private final static String URL_CRIAR_PRODUTO = "/produto/criar-produto";

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ProductService productService;

	@Autowired
	private ObjectMapper objectMapper;

	private ProductListDTO produtoListDTO;

	@BeforeEach
	public void setUp() {
		produtoListDTO = new ProductListDTO();
		List<ProductEntity> produtos = new ArrayList<>();
		ProductEntity produto1 = new ProductEntity();
		produto1.setId(1L);
		produto1.setProductName("Produto 1");
		produtoListDTO.setProdutoList(produtos);
	}

	@Test
	public void criarProdutoComSucessoTest() throws Exception {
			when(productService.criarProduto(produtoListDTO)).thenReturn(Collections.emptyList());
			mockMvc.perform(post(URL_CRIAR_PRODUTO)
							.contentType(MediaType.APPLICATION_JSON)
							.content(objectMapper.writeValueAsString(produtoListDTO)))
					.andExpect(status().isCreated());
			}
	}
