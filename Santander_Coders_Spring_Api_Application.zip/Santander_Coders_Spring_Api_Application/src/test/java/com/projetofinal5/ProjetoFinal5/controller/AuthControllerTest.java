package com.projetofinal5.ProjetoFinal5.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthControllerTest {

	@Test
	void contextLoads() {
	}

}
