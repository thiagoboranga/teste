package com.projetofinal5.ProjetoFinal5.dto;

public record LoginResponseDTO(String token) {
}
