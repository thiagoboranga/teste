package com.projetofinal5.ProjetoFinal5.dto;

public record RegisterDTO(String login, String password, UserRole userRole) {
}
