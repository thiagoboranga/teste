package com.projetofinal5.ProjetoFinal5.dto;

public record UserDTO(String login, String password) {
}
