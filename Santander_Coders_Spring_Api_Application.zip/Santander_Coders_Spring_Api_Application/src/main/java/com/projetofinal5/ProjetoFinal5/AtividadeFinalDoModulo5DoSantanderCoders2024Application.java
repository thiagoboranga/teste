package com.projetofinal5.ProjetoFinal5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeFinalDoModulo5DoSantanderCoders2024Application {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeFinalDoModulo5DoSantanderCoders2024Application.class, args);
	}

}
